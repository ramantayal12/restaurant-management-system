#include<string.h>
#include<iostream>
#include<vector>
using namespace std;

class menu{
public:
	int id;
	string price,time,foodName;
};

