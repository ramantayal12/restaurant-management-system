This project is created by Raman Tayal 18105075, Paras Arora 18105085


This project has command line interface

As the project now contains sqlite3 files it should be run using command
in command line "g++ main.cpp -lsqlite3"
and then "./a.out"

Description of Data Base Files :

1. The File conatining data of food items is items.db
it contains table named "items"
and the table itself contains columns:
a. Food_ID
b. Food_Name 
c. Price
d. Time
